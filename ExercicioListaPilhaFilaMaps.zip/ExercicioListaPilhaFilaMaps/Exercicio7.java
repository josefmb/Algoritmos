import java.util.Queue;

public class Exercicio7 {
    public Integer getFirstElement(Queue<Integer> queue) { return queue.poll(); }
}
