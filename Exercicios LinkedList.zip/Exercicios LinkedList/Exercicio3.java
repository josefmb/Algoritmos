import java.util.LinkedList;

public class Exercicio3 {

    private LinkedList<Integer> m_aLinkedList = new LinkedList<Integer>();
    
    public LinkedList<Integer> getInvertedList(LinkedList<Integer> aIntegers) {
        
        aIntegers.forEach(value -> {
            m_aLinkedList.addFirst(value);
        });

        return m_aLinkedList;
    }
}
