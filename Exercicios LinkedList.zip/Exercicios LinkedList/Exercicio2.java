import java.util.LinkedList;

public class Exercicio2 {
    
    public Integer getElementFromList(Integer iElement, LinkedList<Integer> aIntegers) {
        int iIdx = aIntegers.indexOf(iElement);

        if (iIdx != -1) {
            iElement = aIntegers.get(iIdx);
            aIntegers.remove(iIdx);
        }

        return iElement;
    }
}
