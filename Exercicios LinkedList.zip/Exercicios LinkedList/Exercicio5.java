import java.util.LinkedList;

public class Exercicio5 {

    public Integer getHigherNumber(LinkedList<Integer> aIntegers) {

        Integer value = 0;

        for (Integer integer : aIntegers) {
            if (integer.compareTo(value) <= 0)
                continue;
            
            value = integer;
        }

        return value;
    }
}
