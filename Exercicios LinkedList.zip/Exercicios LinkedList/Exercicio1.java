import java.util.LinkedList;

public class Exercicio1 {

    private LinkedList<Integer> m_aOrdenedList = new LinkedList<Integer>();

    public LinkedList<Integer> getOrdenedList(LinkedList<Integer> aIntegers) {

        Integer iValue = 0;
        int iIndiceRemover = 0;

        while (aIntegers.size() != 0) {

            for (Integer iIndiceAtual = 0; iIndiceAtual < aIntegers.size(); ++iIndiceAtual) {

                if (aIntegers.get(iIndiceAtual) <= iValue)
                    continue;

                iValue = aIntegers.get(iIndiceAtual);
                iIndiceRemover = iIndiceAtual;
            }
            
            aIntegers.remove(iIndiceRemover);
            m_aOrdenedList.addFirst(iValue);

            iValue = 0;
        }
 
        return m_aOrdenedList;
    }
}
