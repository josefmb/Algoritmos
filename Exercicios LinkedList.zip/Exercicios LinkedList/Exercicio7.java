import java.util.LinkedList;

public class Exercicio7 {

    private LinkedList<Integer> m_aIntegers = new LinkedList<Integer>();
    
    public LinkedList<Integer> getUniao(LinkedList<Integer> aLista1, LinkedList<Integer> aLista2) {

        m_aIntegers.clear();
        
        for (Integer integer : aLista1) {
            if (m_aIntegers.contains(integer) == true)
                continue;
            
            m_aIntegers.addLast(integer);
        }

        for (Integer integer : aLista2) {
            if (m_aIntegers.contains(integer) == true)
                continue;
            
            m_aIntegers.addLast(integer);
        }

        return m_aIntegers;
    }

    public LinkedList<Integer> getIntersecao(LinkedList<Integer> aLista1, LinkedList<Integer> aLista2) {

        m_aIntegers.clear();

        for (Integer integer : aLista1) {
            if (aLista2.contains(integer) == true && m_aIntegers.contains(integer) == false)
                m_aIntegers.addLast(integer);
        }

        return m_aIntegers;
    }

    public LinkedList<Integer> getDiferenca(LinkedList<Integer> aLista1, LinkedList<Integer> aLista2) {

        m_aIntegers.clear();

        for (Integer integer : aLista1) {
            if (aLista2.contains(integer) == false && m_aIntegers.contains(integer) == false)
                m_aIntegers.addLast(integer);
        }

        return m_aIntegers;
    }
}
