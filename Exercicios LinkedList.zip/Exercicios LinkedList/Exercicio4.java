import java.util.LinkedList;

public class Exercicio4 {
    
    public LinkedList<Integer> getInvertedList(LinkedList<Integer> aIntegers) {
        
        Integer value = 0;
        for (int idx = 0; idx < aIntegers.size(); ++idx) {
            value = aIntegers.get(idx);
            aIntegers.remove(idx);
            aIntegers.addFirst(value);
        }

        return aIntegers;
    }
}
