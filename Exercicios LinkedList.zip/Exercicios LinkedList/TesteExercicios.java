import java.util.Arrays;
import java.util.LinkedList;

public class TesteExercicios {
    public static void main(String[] args) {

        LinkedList<Integer> aIntegers = new LinkedList<Integer>(Arrays.asList(new Integer[]{ 10, 20, 3, 5, 9, 30 }));

        Exercicio1 exercicio = new Exercicio1();
        LinkedList<Integer> aOrdenedList = exercicio.getOrdenedList(aIntegers);

        System.out.println("Exercicio 1");
        aOrdenedList.forEach(value -> {
            System.out.printf("%d ", value);
        });

        System.out.printf("\n\nExercicio 2\nTamanho do array antes: %d\n", aOrdenedList.size());
        Exercicio2 exercicio2 = new Exercicio2();
        Integer iElement = exercicio2.getElementFromList(Integer.valueOf(30), aOrdenedList);

        System.out.printf("Elemento encontrado: %d\nTamanho do array agora: %d\n", iElement, aOrdenedList.size());

        System.out.println("\nExercicio 3");
        Exercicio3 exercicio3 = new Exercicio3();
        aIntegers = exercicio3.getInvertedList(aOrdenedList);

        aIntegers.forEach(value -> {
            System.out.printf("%d ", value);
        });

        System.out.println("\n\nExercicio 4");
        Exercicio4 exercicio4 = new Exercicio4();
        aIntegers = exercicio4.getInvertedList(aIntegers);

        aIntegers.forEach(value -> {
            System.out.printf("%d ", value);
        });

        System.out.println("\n\nExercicio 5");;
        Exercicio5 exercicio5 = new Exercicio5();
        Integer iHigher = exercicio5.getHigherNumber(aIntegers);

        System.out.printf("%d\n", iHigher);

        System.out.println("\nExercicio 6");
        LinkedList<Integer> aRepeatedNumbers = new LinkedList<Integer>(Arrays.asList(new Integer[]{ 10, 10, 10, 20, 20, 30, 1, 2, 2, 3 }));
        Exercicio6 exercicio6 = new Exercicio6();
        aRepeatedNumbers = exercicio6.getListWithoutRepeatedElements(aRepeatedNumbers);

        aRepeatedNumbers.forEach(value -> {
            System.out.printf("%d ", value);
        });

        System.out.println("\n\nExercicio 7");
        Exercicio7 exercicio7 = new Exercicio7();

        LinkedList<Integer> aConjuntos = new LinkedList<Integer>();
        LinkedList<Integer> aConjunto1 = new LinkedList<Integer>(Arrays.asList(new Integer[]{ 1, 2, 3, 4, 5 }));
        LinkedList<Integer> aConjunto2 = new LinkedList<Integer>(Arrays.asList(new Integer[]{ 4, 5, 6, 7, 8 }));

        System.out.print("Listas:\n{ ");
        aConjunto1.forEach(value -> {
            System.out.printf("%d ", value);
        });
        System.out.print("}\n{ ");
        aConjunto2.forEach(value -> {
            System.out.printf("%d ", value);
        });
        System.out.println("}");

        System.out.print("Uniao: ");
        aConjuntos = exercicio7.getUniao(aConjunto1, aConjunto2);

        aConjuntos.forEach(value -> {
            System.out.printf("%d ", value);
        });

        System.out.print("\nIntersecao: ");
        aConjuntos = exercicio7.getIntersecao(aConjunto1, aConjunto2);

        aConjuntos.forEach(value -> {
            System.out.printf("%d ", value);
        });

        System.out.print("\nDiferenca: ");
        aConjuntos = exercicio7.getDiferenca(aConjunto1, aConjunto2);

        aConjuntos.forEach(value -> {
            System.out.printf("%d ", value);
        });
    }
}
