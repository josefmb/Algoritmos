import java.util.LinkedList;

public class Exercicio6 {
    
    private LinkedList<Integer> m_aIntegers = new LinkedList<Integer>();

    public LinkedList<Integer> getListWithoutRepeatedElements(LinkedList<Integer> aIntegers) {

        for (Integer integer : aIntegers) {
            if (m_aIntegers.contains(integer) == true)
                continue;

            m_aIntegers.addLast(integer);
        }

        return m_aIntegers;
    }
}
