import java.util.ArrayList;
import java.util.Scanner;

public class Questao3 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        ArrayList<String> aNomesAlunos = new ArrayList<String>();
        ArrayList<Float> aNotasAlunos = new ArrayList<Float>();

        System.out.println("> Entre com a quantidade de números para ler:");
        Integer iQtd = Integer.parseInt(teclado.nextLine());

        for (int i = 0; i < iQtd; ++i) {
            System.out.printf("> Aluno %d\n", i + 1);
            aNomesAlunos.add((teclado.nextLine()));

            System.out.printf("> Nota de %s\n", aNomesAlunos.get(i));
            aNotasAlunos.add(Float.parseFloat(teclado.nextLine()));
        }

        float fMedia = getMediaTurma(aNotasAlunos);
        String sAlunos = getAlunosAcimaMedia(aNomesAlunos, aNotasAlunos);

        System.out.printf("Nota da turma: %.1f\nAlunos com a média maior que %.1f\n%s", fMedia, fMedia, sAlunos);

        teclado.close();
    }

    public static float getMediaTurma(ArrayList<Float> aNotasAlunos) {
        float fMedia = 0;

        for (Float fNota : aNotasAlunos)
            fMedia += fNota;

        fMedia /= aNotasAlunos.size();
        return fMedia;
    }

    public static String getAlunosAcimaMedia(ArrayList<String> aNomesAlunos, ArrayList<Float> aNotasAlunos) {
        String sAlunos = "";
        float fMedia = getMediaTurma(aNotasAlunos);

        for (int i = 0; i < aNomesAlunos.size(); ++i) {
            if (aNotasAlunos.get(i) < fMedia)
                continue;

            sAlunos += String.format("%s - %.1f\n", aNomesAlunos.get(i), aNotasAlunos.get(i));
        }

        return sAlunos;
    }
}
