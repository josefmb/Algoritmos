import java.util.ArrayList;
import java.util.Scanner;

public class Questao1 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        ArrayList<Integer> aNumerosMaiores = new ArrayList<Integer>();

        System.out.println("> Entre com a quantidade de números para ler:");
        int iQtd = teclado.nextInt();

        System.out.println("> Qual o número de verificação?");
        int iNumVerificacao = teclado.nextInt();

        int iNumInformado = 0;
        for (int i = 0; i < iQtd; ++i) {
            System.out.printf("> Número %d\n", i + 1);
            iNumInformado = teclado.nextInt();

            if (iNumInformado > iNumVerificacao)
                aNumerosMaiores.add(iNumInformado);
        }

        System.out.printf("%d números maiores que 10", aNumerosMaiores.size());
        teclado.close();
    }
}
