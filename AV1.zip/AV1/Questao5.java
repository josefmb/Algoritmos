import java.util.Scanner;

public class Questao5 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.println("> Qual quantidade de linhas?");
        int iLinhas = teclado.nextInt();

        System.out.println("> Qual quantidade de colunas?");
        int iColunas = teclado.nextInt();

        int aMatriz[][] = new int[iLinhas][iColunas];
        
        for (int iLinha = 0; iLinha < aMatriz.length; ++iLinha) {
            for (int iColuna = 0; iColuna < aMatriz[0].length; ++iColuna) {
                System.out.printf("> Número %d, %d\n", iLinha + 1, iColuna + 1);
                aMatriz[iLinha][iColuna] = teclado.nextInt();
            }
        }

        System.out.println("Matriz");
        imprime(aMatriz);

        int[][] aMatrizSomas = new int[iLinhas][iColunas];
        populaMatrizSomas(aMatrizSomas, aMatriz);

        System.out.println("\nResultado final");
        imprime(aMatrizSomas);
        
        teclado.close();
    }

    public static void imprime(int[][] aMatriz) {
        for (int iLinha = 0; iLinha < aMatriz.length; ++iLinha) {
            for (int iColuna = 0; iColuna < aMatriz[0].length; ++iColuna)
                System.out.printf("%d ", aMatriz[iLinha][iColuna]);

            System.out.println();
        }
    }

    public static void populaMatrizSomas(int[][] aMatrizSomas, int[][] aMatriz) {
        int iProximaLinha = 0;
        int iProximaColuna = 0;

        for (int iLinha = 0; iLinha < aMatriz.length; ++iLinha) {
            for (int iColuna = 0; iColuna < aMatriz[0].length; ++iColuna) {
                iProximaLinha = iLinha + 1;
                iProximaColuna = iColuna + 1;

                if (iLinha + 1 == aMatriz.length)
                    iProximaLinha = 0;
                else
                    iProximaLinha = aMatriz[iLinha + 1][iColuna];

                if (iColuna + 1 == aMatriz[0].length)
                    iProximaColuna = 0;
                else
                    iProximaColuna = aMatriz[iLinha][iColuna + 1];

                aMatrizSomas[iLinha][iColuna] = aMatriz[iLinha][iColuna] + iProximaLinha + iProximaColuna;
            }
        }
    }
}
