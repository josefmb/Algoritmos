import java.util.Scanner;

public class Questao4 {

    static int[][] aMatrizInserida;
    static int[] aSomaLinhas;
    static int[] aSomaColunas;
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.println("> Qual valor de linhas e colunas?");
        int iLinhasColunas = teclado.nextInt();

        aMatrizInserida = new int[iLinhasColunas][iLinhasColunas];
        aSomaLinhas     = new int[iLinhasColunas];
        aSomaColunas    = new int[iLinhasColunas];

        int iLinhaColunaAtual = 0;

        for (int iLinha = 0; iLinha < aMatrizInserida.length; ++iLinha) {
            System.out.printf("> Número %d\n", iLinha + 1);
            iLinhaColunaAtual = teclado.nextInt();

            for (int iColuna = 0; iColuna < aMatrizInserida[0].length; ++iColuna) {
                if (iColuna == 0)
                    aSomaLinhas[iLinha] = iLinhaColunaAtual * iLinhasColunas;
                
                aMatrizInserida[iLinha][iColuna] = iLinhaColunaAtual;
                aSomaColunas[iColuna] += iLinhaColunaAtual;
            }
        }

        System.out.println("Matriz");
        imprime(false);
        System.out.println("Resultado final");
        imprime(true);

        teclado.close();
    }

    public static void imprime(Boolean bResultadoFinal) {
        for (int iLinha = 0; iLinha < aMatrizInserida.length; ++iLinha) {
            for (int iColuna = 0; iColuna < aMatrizInserida[0].length; ++iColuna) {
                System.out.printf("%d ", aMatrizInserida[iLinha][iColuna]);

                if (iColuna + 1 == aMatrizInserida[0].length && bResultadoFinal == true)
                    System.out.printf("- %d", aSomaLinhas[iLinha]);
            }

            System.out.println();
        }

        if (bResultadoFinal == true) {
            boolean bTracosImpressos = false;

            for (int iSomaColunas = 0; iSomaColunas < aSomaColunas.length; ++iSomaColunas)
                if (bTracosImpressos == true) {
                    System.out.printf("%d ", aSomaColunas[iSomaColunas]);
                } else if (iSomaColunas + 1 != aSomaColunas.length) {
                    System.out.print("- ");
                } else {
                    System.out.println("- ");
                    bTracosImpressos = true;
                    iSomaColunas = -1;
                }
        }
    }
}
