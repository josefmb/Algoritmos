import java.util.ArrayList;
import java.util.Scanner;

public class Questao2 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        ArrayList<Integer> aNumerosLidos = new ArrayList<Integer>();

        System.out.println("> Entre com a quantidade de números para ler:");
        int iQtd = teclado.nextInt();

        for (int i = 0; i < iQtd; ++i) {
            System.out.printf("> Número %d\n", i + 1);
            aNumerosLidos.add(teclado.nextInt());
        }

        System.out.print("Números lidos: ");
        for (int i = 0; i < iQtd; ++i)
            System.out.printf("%d ", aNumerosLidos.get(i));

        System.out.print("\nNúmeros pares invertidos: ");
        for (int i = aNumerosLidos.size() - 1; i >= 0; --i) {
            if (aNumerosLidos.get(i) % 2 == 0)
                System.out.printf("%d ", aNumerosLidos.get(i));
        }

        teclado.close();
    }
}
