public class Carta {
    private String nome = new String();
    private String naipe = new String();

    public String getNome() {
        return this.nome;
    }

    public void setNome(String sNome) {
        this.nome = sNome;
    }

    public String getNaipe() {
        return this.naipe;
    }

    public void setNaipe(String sNaipe) {
        this.naipe = sNaipe;
    }
}
