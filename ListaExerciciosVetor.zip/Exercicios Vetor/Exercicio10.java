public class Exercicio10 {
    public static void main(String[] args) {
        Baralho baralho = new Baralho();
        baralho.imprimeBaralho();
        
        baralho.embaralha();
        baralho.embaralha();
 
        baralho.imprimeBaralho();
    }
}
